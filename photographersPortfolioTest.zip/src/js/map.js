function initMap() {
    var place = {lat: 10.748182, lng: 16.5607998};
    var map = new google.maps.Map(
        document.getElementById('map'), {zoom: 1.51, center: place});
  }